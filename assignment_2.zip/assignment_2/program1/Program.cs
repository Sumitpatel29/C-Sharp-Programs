﻿using System;

namespace program1
{
    class Program
    {
        static void Main(string[] args)
        {
           Console.WriteLine("Enter 1st number:");
           int a=Convert.ToInt32(Console.ReadLine());
           Console.WriteLine("Enter 2nd number:");
           int b=Convert.ToInt32(Console.ReadLine());
            if(a>b)
            {
                Console.WriteLine(a+" is largest number");
            }
            else
            {
                 Console.WriteLine(b+" is largest number");
            }
           
        }
    }
}
