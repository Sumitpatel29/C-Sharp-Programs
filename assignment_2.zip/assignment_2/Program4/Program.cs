﻿using System;

namespace Program4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter average marks of the student: ");
            int avg=Convert.ToInt32(Console.ReadLine());
            if(avg>=60)
            {
                Console.WriteLine("1st division");
            }
            else if(avg>=50)
            {
                Console.WriteLine("2nd division");
            }
            else if(avg>=30)
            {
                Console.WriteLine("3rd division");
            }
            else
            {
                Console.WriteLine("Fail!!");
            }
        }
    }
}
