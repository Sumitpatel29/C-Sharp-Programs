﻿using System;

namespace Program4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter value of x: ");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter value of y: ");
            int y = Convert.ToInt32(Console.ReadLine());
            if(x>0 && y>0)
            {
                Console.WriteLine("This co-ordinate lies in 1st quadrant.");
            }
            else if(x>0 && y<0)
            {
                Console.WriteLine("This co-ordinate lies in 2nd quadrant.");
            }
            else if(x<0 && y<0)
            {
                Console.WriteLine("This co-ordinate lies in 3rd quadrant.");
            }
            else
            {
                Console.WriteLine("This co-ordinate lies in 4th quadrant.");
            }
        }
    }
}
