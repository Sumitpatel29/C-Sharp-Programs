﻿using System;

namespace Program7
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Enter 1st number: ");
            int a=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 2nd number: ");
            int b=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 1 to perform addition.");
            Console.WriteLine("Enter 2 to perform substraction.");
            Console.WriteLine("Enter 3 to perform multiplication.");
            Console.WriteLine("Enter 4 to perform division.");
              n=Convert.ToInt32(Console.ReadLine());
            switch(n)
            {
                case 1:
                int sum=a+b;
                Console.WriteLine("the addition of entered numbers is "+sum);
                break;
                case 2:
                int sub=a-b;
                Console.WriteLine("the substraction of entered numbers is "+sub);
                break;
                case 3:
                int mul=a-b;
                Console.WriteLine("the multiplication of entered numbers is "+mul);
                break;
                 case 4:
                 int div=a/b;
                Console.WriteLine("the division of entered number is "+div);
                break;
                default:
                Console.WriteLine("Entered invalid input");
                break;

            }

        }
    }
}
