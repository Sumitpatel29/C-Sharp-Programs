﻿using System;

namespace Program3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number to check even or not: ");
            int n=Convert.ToInt32(Console.ReadLine());
            if(n%2==0)
            {
                Console.WriteLine("The number "+n+" is even.");
            }
            else
            {
                Console.WriteLine("The number "+n+" is odd.");  
            }
        }
    }
}
