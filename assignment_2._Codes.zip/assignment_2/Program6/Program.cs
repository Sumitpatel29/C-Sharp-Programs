﻿using System;

namespace Program6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter an alphabet to check that is vowel or not: ");
            char alphabet=Convert.ToChar(Console.ReadLine());
            switch(alphabet)
            {
            case 'a':
            case 'A': 
            case 'e': 
            case 'E': 
            case 'i': 
            case 'I': 
            case 'o': 
            case 'O': 
            case 'u':
            case 'U':
            Console.WriteLine(alphabet+" is Vowel.");
            break;
            default : Console.WriteLine(alphabet+" is consonant");
            break;
            }
        }
    }
}
