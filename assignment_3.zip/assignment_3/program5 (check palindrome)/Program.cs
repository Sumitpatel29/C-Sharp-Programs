﻿using System;

namespace program5__check_palindrome_
{
    class Program
    {
        //If the reversed number is same as original number then it is called as palindrome numebr
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a numbewr to cehck palindrome or not:");
            int n = Convert.ToInt32(Console.ReadLine());
            int r=0;
            int temp = n;
            while(n>0)
            {
                r=r*10+n%10;
                n=n/10;
            }
            if(temp==r)
            {
                Console.WriteLine("The number is Palindrome.");
            }
            else
            {
                Console.WriteLine("The number is not Palindrome");
            }
        }
    }
}
