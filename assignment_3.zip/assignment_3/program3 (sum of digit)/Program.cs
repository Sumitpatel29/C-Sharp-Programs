﻿using System;

namespace program3__sum_of_digit_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number to find the sum of its digits: ");
            int n = Convert.ToInt32(Console.ReadLine());
            int sum = 0;
            while (n > 0)
            {
                sum = sum + n%10;
                n = n/10;
            }
            Console.WriteLine("The sum of the digits is: " + sum);

        }
    }
}
