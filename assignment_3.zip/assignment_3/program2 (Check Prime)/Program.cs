﻿using System;

namespace program2__Check_Prime_
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter a number to check that is prime or not: ");
            int n = Convert.ToInt32(Console.ReadLine());
            int count = 0;
            for (int i = 1; i <= n; i++)
            {
              if (n % i == 0)
              {
                count++;
              }
            }
            if (count == 2)
            {
              Console.WriteLine(n + " is a prime number");
            }
             else
             {
               Console.WriteLine(n + " is not a prime number");
             }
          }
    }
  }
    

