﻿using System;

namespace program4__reverse_a_number_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number to reverse a number: ");
            int n = Convert.ToInt32(Console.ReadLine());
            int r=0;
            while(n>0)
            {
                r=r*10+n%10;
                n=n/10;
            }
           Console.WriteLine("The reversed number is: "r); 
            
        }
    }
}

