﻿using System;
//Convert farhenhite degree tempetature to celcius degree temperature
namespace program1
{
    class Program
    {
        static void Main(string[] args)
        {
            double f,c;
            Console.WriteLine("Enter 1 for converting farhenhite degree temperature to celcius degree tempreature.");
            Console.WriteLine("Enter 2 for converting celcius degree temperature to farhenhite degree tempreature.");
            int n=Convert.ToInt32(Console.ReadLine());

            switch(n)
            {
                case 1: 
                Console.WriteLine("Enter the farenhite temperature:");
                f = Convert.ToDouble(Console.ReadLine());
                c =((f-32)*5)/9; //to convert farhenhite to celcius
                Console.WriteLine("The temperarture in celcius is: "+c);
                break;

                case 2: 
                Console.WriteLine("Enter the Celcius temperature:");
                c = Convert.ToDouble(Console.ReadLine());
                f = c*1.8+32;  //to convert celcius to farhenhite
                Console.WriteLine("The temperarture in farenhite is: "+f);
                break;

                default:
                Console.WriteLine("Invalid Input");
                break;
            }
        }
    }
}
