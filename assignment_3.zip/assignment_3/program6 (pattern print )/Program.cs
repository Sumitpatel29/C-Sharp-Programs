﻿using System;

namespace program6__pattern_print__
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i=0;i<=5;i++)
            {
                for(int j=0;j<=i;j++)
                {
                    Console.Write(j+" ");
                }
                Console.WriteLine();
            }
            for(int i=5;i>=0;i--)
            {
               
                for(int j=0;j<=i;j++)
                {
                    Console.Write(j+" ");
                }
                 Console.WriteLine();
            }
        }
    }
}
