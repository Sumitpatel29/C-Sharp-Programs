﻿using System;

namespace SalesPerson_problem
{
    class Program
    {
        static void distance(int begin,int end)
        {
            int dist = end-begin;
            Console.WriteLine("You travelled "+ dist +" miles at 0.35$ per mile");
            //calculate reimbursement
            double reim=dist*0.35;
            Console.WriteLine("Your reimbursement is "+ reim + "$.");
        }
        static void Main(string[] args)
        {
            Console.WriteLine("=====MILAGE REIMBURSEMENT CALCULATOR=====");
            Console.WriteLine("Enter begining odometer reading:");
            int begin = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter ending odometer reading:");
            int end = Convert.ToInt32(Console.ReadLine());
             distance(begin,end); 

        }
    }
}
