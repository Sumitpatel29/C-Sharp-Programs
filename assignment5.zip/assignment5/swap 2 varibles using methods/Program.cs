﻿using System;

namespace swap_2_varibles_using_methods
{
    class Program
    {
        static void swap(int a,int b)
        {
            Console.WriteLine("Before swapping value of a= "+a+" and b= "+b);
            int temp = a;
            a = b;
            b = temp;
            Console.WriteLine("After swapping value of a= "+a+" and b= "+b);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter value of a: ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter value of b: ");
            int b = Convert.ToInt32(Console.ReadLine());
            swap(a, b);
        }
    }
}
