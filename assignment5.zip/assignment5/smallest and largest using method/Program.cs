﻿using System;

namespace smallest_and_largest_using_method
{
    class Program
    {
        static void largeSmall(int a,int b,int c)
        {
            if (a > b && a>c)
            {
                Console.WriteLine("Largest number is: " + a);
            }
            else if (b > a && b>c)
            {
                Console.WriteLine("Largest number is: " + b);
            }
            else
            {
                Console.WriteLine("Largest number is: " + c);
            }

        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter value of a: "); 
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter value of b: ");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter value of c: ");
            int c = Convert.ToInt32(Console.ReadLine());
            largeSmall(a, b, c);

        }
    }
}
