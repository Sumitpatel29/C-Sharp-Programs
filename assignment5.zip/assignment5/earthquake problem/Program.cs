﻿using System;

namespace earthquake_problem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Ritcher Scale number:");
            double n=Convert.ToDouble(Console.ReadLine());
            if (n < 5.0)
            {
                Console.WriteLine("Little or no damage");
            }
            else if (5.0<= n  && n <= 5.5)
            {
                Console.WriteLine("Some damage");
            }
            else if( 5.5 <= n && n <=6.5)
            {
                Console.WriteLine("Serious damage");
            }
            else if(6.5 <= n && n <= 7.5)
            {
               Console.WriteLine("Disaster");
            }
            else
            {
                Console.WriteLine("Catastrophe");
            }
        }
    }
}
