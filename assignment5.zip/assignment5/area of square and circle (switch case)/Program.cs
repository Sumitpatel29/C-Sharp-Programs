﻿using System;

namespace area_of_square_and_circle__switch_case_
{
    class Program
    {
        static double areaSquare(double side)
        {
            double area=side*side;
            return area;
        }

        static double areaCircle(double r)
        {
            double area = 3.14 * r * r;
            return area;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("CALCULATE AREA OF SQUARE AND CIRCLE");
            Console.WriteLine("To find area of a Square press s.");
            Console.WriteLine("To find area of a Circle press c.");
            char choice = Convert.ToChar(Console.ReadLine());
            switch (choice)
            {
                case 's':
                case 'S': 
                Console.WriteLine("Enter side of the square: ");
                double side = Convert.ToDouble(Console.ReadLine());
                double area = areaSquare(side);
                Console.WriteLine("Area of the square is: "+area);
                break;

                case 'c':
                case 'C':
                Console.WriteLine("Enter radius of the circle: ");
                double r = Convert.ToDouble(Console.ReadLine());
                double area1 = areaCircle(r);
                Console.WriteLine("Area of circle is: "+area1);
                break;

                default: 
                Console.WriteLine("Invalid choice");
                break;
            }
        }
    }
}
