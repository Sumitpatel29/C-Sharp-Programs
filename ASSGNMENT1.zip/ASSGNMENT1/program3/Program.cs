﻿using System;

namespace program3
{
    class Program
    {
        static void Main(string[] args)
        {
            double Base;
            double height;
            Console.WriteLine("Enter the base of the triangle:");
            Base=Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the height of the triangle:");
            height=Convert.ToDouble(Console.ReadLine());
            double hypotenuse=Math.Sqrt((Base*Base)+(height*height));
            Console.WriteLine("The hypotenuse of the triangle is: "+hypotenuse);
        }
    }
}
