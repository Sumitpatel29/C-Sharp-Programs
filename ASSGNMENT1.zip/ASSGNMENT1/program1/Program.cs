﻿using System;

namespace program1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num=10;
            string name="sumit";
            double price=99.5;
            Console.WriteLine("Number:"+num);
            Console.WriteLine("Name:"+name);
            Console.WriteLine("Price:"+price);
        } 
    }
}
