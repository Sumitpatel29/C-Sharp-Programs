﻿using System;

namespace program2
{
    class Program
    {
        const double PI=3.14159;   
        static void Main(string[] args)
        {
            Console.WriteLine("Enter radius of the circle:");
            double radius = Convert.ToDouble(Console.ReadLine());
            double area = PI * radius*radius;
            Console.WriteLine("The radius of circle is "+radius+" and area is "+area);
        }
    }
}
