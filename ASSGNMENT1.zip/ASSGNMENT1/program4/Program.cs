﻿using System;

namespace program4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("The maximum value of decimal is {0:E}",Decimal.MaxValue);
            Console.WriteLine("The maximum value of float is {0:E}",Single.MaxValue);
            Console.WriteLine("The maximum value of double is {0:E}",Double.MaxValue);
        }
    }
}
